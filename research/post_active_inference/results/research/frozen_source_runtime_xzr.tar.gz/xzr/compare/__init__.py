"""Xeno / Ziran Philosophical Runtime."""
